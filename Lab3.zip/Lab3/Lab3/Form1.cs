﻿//A2502
//Lab 3
//2-12-17
//CIS199-01
//This lab allows the user to input a price of their meal, and calculates
//what their tip should be based on a low, medium, and high tip rate.  
//Displays all three amounts in their respective output labels.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        //constant fields
        const decimal LOW_TIP_RATE = 0.15m;
        const decimal MED_TIP_RATE = 0.18m;
        const decimal HIGH_TIP_RATE = 0.20m;

        public Form1()
        {
            InitializeComponent();
        }

        private void calculateTipButton_Click(object sender, EventArgs e)
        {
            decimal mealPrice; //The price of the meal

            //Get the price of the meal
            mealPrice = decimal.Parse(mealPriceTextBox.Text);

            //calculate the low tip rate, based on the meal price input
            mealPrice *= LOW_TIP_RATE;

            //display the low tip rate, based on the meal price input, formatted as currency
            lowTipRateOutputLabel.Text = mealPrice.ToString("c");

            //get the price of the meal
            mealPrice = decimal.Parse(mealPriceTextBox.Text);
            
            //calculate the medium tip rate, based on the meal price input
            mealPrice *= MED_TIP_RATE;

            //display the medium tip rate, based on the meal price input, formatted as currency
            medTipRateOutputLabel.Text = mealPrice.ToString("c");

            //get the price of the meal
            mealPrice = decimal.Parse(mealPriceTextBox.Text);

            //calculate the high tip rate, based on the meal price input
            mealPrice *= HIGH_TIP_RATE;

            //display the high tip rate, based on the meal price input, formatted as currency
            highTipRateOutputLabel.Text = mealPrice.ToString("c");


        }
    }
}
