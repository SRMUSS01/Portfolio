﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lowTipRateLabel = new System.Windows.Forms.Label();
            this.mealPriceTextBox = new System.Windows.Forms.TextBox();
            this.calculateTipButton = new System.Windows.Forms.Button();
            this.lowTipRateOutputLabel = new System.Windows.Forms.Label();
            this.medTipRateOutputLabel = new System.Windows.Forms.Label();
            this.highTipRateOutputLabel = new System.Windows.Forms.Label();
            this.medTipRateLabel = new System.Windows.Forms.Label();
            this.highTipRateLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter price of meal:";
            // 
            // lowTipRateLabel
            // 
            this.lowTipRateLabel.AutoSize = true;
            this.lowTipRateLabel.Location = new System.Drawing.Point(128, 86);
            this.lowTipRateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lowTipRateLabel.Name = "lowTipRateLabel";
            this.lowTipRateLabel.Size = new System.Drawing.Size(41, 20);
            this.lowTipRateLabel.TabIndex = 1;
            this.lowTipRateLabel.Text = "15%";
            // 
            // mealPriceTextBox
            // 
            this.mealPriceTextBox.Location = new System.Drawing.Point(190, 12);
            this.mealPriceTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mealPriceTextBox.Name = "mealPriceTextBox";
            this.mealPriceTextBox.Size = new System.Drawing.Size(148, 26);
            this.mealPriceTextBox.TabIndex = 4;
            // 
            // calculateTipButton
            // 
            this.calculateTipButton.Location = new System.Drawing.Point(146, 297);
            this.calculateTipButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.calculateTipButton.Name = "calculateTipButton";
            this.calculateTipButton.Size = new System.Drawing.Size(135, 35);
            this.calculateTipButton.TabIndex = 8;
            this.calculateTipButton.Text = "Calculate Tip";
            this.calculateTipButton.UseVisualStyleBackColor = false;
            this.calculateTipButton.Click += new System.EventHandler(this.calculateTipButton_Click);
            // 
            // lowTipRateOutputLabel
            // 
            this.lowTipRateOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowTipRateOutputLabel.Location = new System.Drawing.Point(186, 86);
            this.lowTipRateOutputLabel.Name = "lowTipRateOutputLabel";
            this.lowTipRateOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.lowTipRateOutputLabel.TabIndex = 9;
            // 
            // medTipRateOutputLabel
            // 
            this.medTipRateOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.medTipRateOutputLabel.Location = new System.Drawing.Point(186, 151);
            this.medTipRateOutputLabel.Name = "medTipRateOutputLabel";
            this.medTipRateOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.medTipRateOutputLabel.TabIndex = 10;
            // 
            // highTipRateOutputLabel
            // 
            this.highTipRateOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highTipRateOutputLabel.Location = new System.Drawing.Point(186, 226);
            this.highTipRateOutputLabel.Name = "highTipRateOutputLabel";
            this.highTipRateOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.highTipRateOutputLabel.TabIndex = 11;
            // 
            // medTipRateLabel
            // 
            this.medTipRateLabel.AutoSize = true;
            this.medTipRateLabel.Location = new System.Drawing.Point(128, 152);
            this.medTipRateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.medTipRateLabel.Name = "medTipRateLabel";
            this.medTipRateLabel.Size = new System.Drawing.Size(41, 20);
            this.medTipRateLabel.TabIndex = 12;
            this.medTipRateLabel.Text = "18%";
            // 
            // highTipRateLabel
            // 
            this.highTipRateLabel.AutoSize = true;
            this.highTipRateLabel.Location = new System.Drawing.Point(128, 227);
            this.highTipRateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.highTipRateLabel.Name = "highTipRateLabel";
            this.highTipRateLabel.Size = new System.Drawing.Size(41, 20);
            this.highTipRateLabel.TabIndex = 13;
            this.highTipRateLabel.Text = "20%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 351);
            this.Controls.Add(this.highTipRateLabel);
            this.Controls.Add(this.medTipRateLabel);
            this.Controls.Add(this.highTipRateOutputLabel);
            this.Controls.Add(this.medTipRateOutputLabel);
            this.Controls.Add(this.lowTipRateOutputLabel);
            this.Controls.Add(this.calculateTipButton);
            this.Controls.Add(this.mealPriceTextBox);
            this.Controls.Add(this.lowTipRateLabel);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Lab 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lowTipRateLabel;
        private System.Windows.Forms.TextBox mealPriceTextBox;
        private System.Windows.Forms.Button calculateTipButton;
        private System.Windows.Forms.Label lowTipRateOutputLabel;
        private System.Windows.Forms.Label medTipRateOutputLabel;
        private System.Windows.Forms.Label highTipRateOutputLabel;
        private System.Windows.Forms.Label medTipRateLabel;
        private System.Windows.Forms.Label highTipRateLabel;
    }
}

