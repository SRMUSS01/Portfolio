﻿//A2502
//CIS199-01
//3-12-17
//This code displays 4 different star patterns and declares variables for the numbers of rows, stars, and spaces to produce each pattern
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Pattern A
            Console.WriteLine("Pattern A");//displays Pattern A

            const int MAX_ROWS = 10; //declare variable for the max number of rows, 10
            
            for (int rowa = 1; rowa <= MAX_ROWS; rowa++) //stars go from 1 to 10 and increase by 1 each row
            {
                for (int stara = 1; stara <= rowa; stara++) 
                    Console.Write("*"); 
                Console.WriteLine(); 
            }
            //Pattern B
            Console.WriteLine(" Pattern B"); // displays Pattern B

            for (int rowb = 1; rowb <= MAX_ROWS; rowb++)//stars go from 10 to 1 and decrease by 1 each row
            {
                for (int starb = 10; starb >= rowb; starb--)
                    Console.Write("*");
                Console.WriteLine();
            }
            //Pattern C
            Console.WriteLine("Pattern C"); //displays Pattern C

            for (int rowc = 1; rowc <= MAX_ROWS; rowc++) //stars go from 10 to 1 and decrease by 1 each row and spaces go from 0 to 9 and increase by 1 each row 
            {
                for (int space = 1; space < rowc; space++)
                {
                    Console.Write(" ");
                }
                for (int starc = 10; starc >= rowc; starc--)
                    Console.Write("*");
                Console.WriteLine();
            }
            //Pattern D
            Console.WriteLine(" Pattern D"); //displays D Pattern D

            for (int rowc = 1; rowc <= MAX_ROWS; rowc++) //stars go from 1 to 10 and increase by 1 each row and spaces go from 9 to 0 and decrease by 1 each row
            {
                for (int space = 10; space > rowc; space--)
                {
                Console.Write(" ");
            }
            for (int starc = 1; starc <= rowc; starc++)
                Console.Write("*");
            Console.WriteLine();
            }
        }
    }
}
