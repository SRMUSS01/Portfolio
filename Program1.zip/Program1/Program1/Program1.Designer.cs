﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.squareFeetLabel = new System.Windows.Forms.Label();
            this.coatNumberLabel = new System.Windows.Forms.Label();
            this.paintPriceLabel = new System.Windows.Forms.Label();
            this.squareFeetTextBox = new System.Windows.Forms.TextBox();
            this.coatsDesiredTextBox = new System.Windows.Forms.TextBox();
            this.paintPriceTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.totalSquareFeetLabel = new System.Windows.Forms.Label();
            this.gallonsPaintRequiredLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborRequiredLabel = new System.Windows.Forms.Label();
            this.costOfPaintLabel = new System.Windows.Forms.Label();
            this.costOfLaborLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalSquareFeetOutputLabel = new System.Windows.Forms.Label();
            this.gallonsOfPaintOutputLabel = new System.Windows.Forms.Label();
            this.hourOfLaborOutputLabel = new System.Windows.Forms.Label();
            this.costOfPaintOutputLabel = new System.Windows.Forms.Label();
            this.costOfLaborOutputLabel = new System.Windows.Forms.Label();
            this.totalCostOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // squareFeetLabel
            // 
            this.squareFeetLabel.AutoSize = true;
            this.squareFeetLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.squareFeetLabel.Location = new System.Drawing.Point(70, 23);
            this.squareFeetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.squareFeetLabel.Name = "squareFeetLabel";
            this.squareFeetLabel.Size = new System.Drawing.Size(194, 20);
            this.squareFeetLabel.TabIndex = 0;
            this.squareFeetLabel.Text = "Square feet to be painted:";
            // 
            // coatNumberLabel
            // 
            this.coatNumberLabel.AutoSize = true;
            this.coatNumberLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.coatNumberLabel.Location = new System.Drawing.Point(70, 73);
            this.coatNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.coatNumberLabel.Name = "coatNumberLabel";
            this.coatNumberLabel.Size = new System.Drawing.Size(186, 20);
            this.coatNumberLabel.TabIndex = 1;
            this.coatNumberLabel.Text = "Number of coats desired:";
            // 
            // paintPriceLabel
            // 
            this.paintPriceLabel.AutoSize = true;
            this.paintPriceLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.paintPriceLabel.Location = new System.Drawing.Point(70, 123);
            this.paintPriceLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.paintPriceLabel.Name = "paintPriceLabel";
            this.paintPriceLabel.Size = new System.Drawing.Size(178, 20);
            this.paintPriceLabel.TabIndex = 2;
            this.paintPriceLabel.Text = "Price of paint per gallon:";
            // 
            // squareFeetTextBox
            // 
            this.squareFeetTextBox.Location = new System.Drawing.Point(270, 20);
            this.squareFeetTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.squareFeetTextBox.Name = "squareFeetTextBox";
            this.squareFeetTextBox.Size = new System.Drawing.Size(148, 26);
            this.squareFeetTextBox.TabIndex = 3;
            // 
            // coatsDesiredTextBox
            // 
            this.coatsDesiredTextBox.Location = new System.Drawing.Point(270, 70);
            this.coatsDesiredTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.coatsDesiredTextBox.Name = "coatsDesiredTextBox";
            this.coatsDesiredTextBox.Size = new System.Drawing.Size(148, 26);
            this.coatsDesiredTextBox.TabIndex = 4;
            this.coatsDesiredTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // paintPriceTextBox
            // 
            this.paintPriceTextBox.Location = new System.Drawing.Point(270, 120);
            this.paintPriceTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.paintPriceTextBox.Name = "paintPriceTextBox";
            this.paintPriceTextBox.Size = new System.Drawing.Size(148, 26);
            this.paintPriceTextBox.TabIndex = 5;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(171, 166);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(97, 31);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // totalSquareFeetLabel
            // 
            this.totalSquareFeetLabel.AutoSize = true;
            this.totalSquareFeetLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.totalSquareFeetLabel.Location = new System.Drawing.Point(14, 236);
            this.totalSquareFeetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalSquareFeetLabel.Name = "totalSquareFeetLabel";
            this.totalSquareFeetLabel.Size = new System.Drawing.Size(230, 20);
            this.totalSquareFeetLabel.TabIndex = 7;
            this.totalSquareFeetLabel.Text = "Total square feet to be painted:";
            // 
            // gallonsPaintRequiredLabel
            // 
            this.gallonsPaintRequiredLabel.AutoSize = true;
            this.gallonsPaintRequiredLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.gallonsPaintRequiredLabel.Location = new System.Drawing.Point(14, 276);
            this.gallonsPaintRequiredLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gallonsPaintRequiredLabel.Name = "gallonsPaintRequiredLabel";
            this.gallonsPaintRequiredLabel.Size = new System.Drawing.Size(186, 20);
            this.gallonsPaintRequiredLabel.TabIndex = 8;
            this.gallonsPaintRequiredLabel.Text = "Gallons of paint required:";
            // 
            // hoursOfLaborRequiredLabel
            // 
            this.hoursOfLaborRequiredLabel.AutoSize = true;
            this.hoursOfLaborRequiredLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.hoursOfLaborRequiredLabel.Location = new System.Drawing.Point(14, 316);
            this.hoursOfLaborRequiredLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hoursOfLaborRequiredLabel.Name = "hoursOfLaborRequiredLabel";
            this.hoursOfLaborRequiredLabel.Size = new System.Drawing.Size(175, 20);
            this.hoursOfLaborRequiredLabel.TabIndex = 9;
            this.hoursOfLaborRequiredLabel.Text = "Hours of labor required:";
            // 
            // costOfPaintLabel
            // 
            this.costOfPaintLabel.AutoSize = true;
            this.costOfPaintLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.costOfPaintLabel.Location = new System.Drawing.Point(14, 357);
            this.costOfPaintLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.costOfPaintLabel.Name = "costOfPaintLabel";
            this.costOfPaintLabel.Size = new System.Drawing.Size(103, 20);
            this.costOfPaintLabel.TabIndex = 10;
            this.costOfPaintLabel.Text = "Cost of paint:";
            // 
            // costOfLaborLabel
            // 
            this.costOfLaborLabel.AutoSize = true;
            this.costOfLaborLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.costOfLaborLabel.Location = new System.Drawing.Point(14, 394);
            this.costOfLaborLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.costOfLaborLabel.Name = "costOfLaborLabel";
            this.costOfLaborLabel.Size = new System.Drawing.Size(103, 20);
            this.costOfLaborLabel.TabIndex = 11;
            this.costOfLaborLabel.Text = "Cost of labor:";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.totalCostLabel.Location = new System.Drawing.Point(14, 430);
            this.totalCostLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(82, 20);
            this.totalCostLabel.TabIndex = 12;
            this.totalCostLabel.Text = "Total cost:";
            // 
            // totalSquareFeetOutputLabel
            // 
            this.totalSquareFeetOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.totalSquareFeetOutputLabel.Location = new System.Drawing.Point(243, 237);
            this.totalSquareFeetOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalSquareFeetOutputLabel.Name = "totalSquareFeetOutputLabel";
            this.totalSquareFeetOutputLabel.Size = new System.Drawing.Size(55, 20);
            this.totalSquareFeetOutputLabel.TabIndex = 13;
            this.totalSquareFeetOutputLabel.Click += new System.EventHandler(this.totalSquareFeetOutputLabel_Click);
            // 
            // gallonsOfPaintOutputLabel
            // 
            this.gallonsOfPaintOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.gallonsOfPaintOutputLabel.Location = new System.Drawing.Point(211, 276);
            this.gallonsOfPaintOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gallonsOfPaintOutputLabel.Name = "gallonsOfPaintOutputLabel";
            this.gallonsOfPaintOutputLabel.Size = new System.Drawing.Size(56, 20);
            this.gallonsOfPaintOutputLabel.TabIndex = 14;
            this.gallonsOfPaintOutputLabel.Click += new System.EventHandler(this.gallonsOfPaintOutputLabel_Click);
            // 
            // hourOfLaborOutputLabel
            // 
            this.hourOfLaborOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.hourOfLaborOutputLabel.Location = new System.Drawing.Point(205, 316);
            this.hourOfLaborOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hourOfLaborOutputLabel.Name = "hourOfLaborOutputLabel";
            this.hourOfLaborOutputLabel.Size = new System.Drawing.Size(62, 20);
            this.hourOfLaborOutputLabel.TabIndex = 15;
            // 
            // costOfPaintOutputLabel
            // 
            this.costOfPaintOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.costOfPaintOutputLabel.Location = new System.Drawing.Point(125, 356);
            this.costOfPaintOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.costOfPaintOutputLabel.Name = "costOfPaintOutputLabel";
            this.costOfPaintOutputLabel.Size = new System.Drawing.Size(194, 20);
            this.costOfPaintOutputLabel.TabIndex = 16;
            // 
            // costOfLaborOutputLabel
            // 
            this.costOfLaborOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.costOfLaborOutputLabel.Location = new System.Drawing.Point(125, 394);
            this.costOfLaborOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.costOfLaborOutputLabel.Name = "costOfLaborOutputLabel";
            this.costOfLaborOutputLabel.Size = new System.Drawing.Size(194, 20);
            this.costOfLaborOutputLabel.TabIndex = 17;
            // 
            // totalCostOutputLabel
            // 
            this.totalCostOutputLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.totalCostOutputLabel.Location = new System.Drawing.Point(103, 431);
            this.totalCostOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalCostOutputLabel.Name = "totalCostOutputLabel";
            this.totalCostOutputLabel.Size = new System.Drawing.Size(194, 20);
            this.totalCostOutputLabel.TabIndex = 18;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 456);
            this.Controls.Add(this.totalCostOutputLabel);
            this.Controls.Add(this.costOfLaborOutputLabel);
            this.Controls.Add(this.costOfPaintOutputLabel);
            this.Controls.Add(this.hourOfLaborOutputLabel);
            this.Controls.Add(this.gallonsOfPaintOutputLabel);
            this.Controls.Add(this.totalSquareFeetOutputLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.costOfLaborLabel);
            this.Controls.Add(this.costOfPaintLabel);
            this.Controls.Add(this.hoursOfLaborRequiredLabel);
            this.Controls.Add(this.gallonsPaintRequiredLabel);
            this.Controls.Add(this.totalSquareFeetLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.paintPriceTextBox);
            this.Controls.Add(this.coatsDesiredTextBox);
            this.Controls.Add(this.squareFeetTextBox);
            this.Controls.Add(this.paintPriceLabel);
            this.Controls.Add(this.coatNumberLabel);
            this.Controls.Add(this.squareFeetLabel);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Program1";
            this.Text = "Program 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label squareFeetLabel;
        private System.Windows.Forms.Label coatNumberLabel;
        private System.Windows.Forms.Label paintPriceLabel;
        private System.Windows.Forms.TextBox squareFeetTextBox;
        private System.Windows.Forms.TextBox coatsDesiredTextBox;
        private System.Windows.Forms.TextBox paintPriceTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label totalSquareFeetLabel;
        private System.Windows.Forms.Label gallonsPaintRequiredLabel;
        private System.Windows.Forms.Label hoursOfLaborRequiredLabel;
        private System.Windows.Forms.Label costOfPaintLabel;
        private System.Windows.Forms.Label costOfLaborLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label totalSquareFeetOutputLabel;
        private System.Windows.Forms.Label gallonsOfPaintOutputLabel;
        private System.Windows.Forms.Label hourOfLaborOutputLabel;
        private System.Windows.Forms.Label costOfPaintOutputLabel;
        private System.Windows.Forms.Label costOfLaborOutputLabel;
        private System.Windows.Forms.Label totalCostOutputLabel;
    }
}

