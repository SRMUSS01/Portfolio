﻿//A2502
//Program 1
//2-14-17
//CIS199-01
//This program allows the user to input data about the square feet of the wall they want covered, how many coats of paint they want,
//and the cost of paint per gallon
//This program calculates their inputs based on additional predetermined information, and then displays the calculations in the output labels at the bottom.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        //declare constants
        const decimal hoursRequiredPerGallon = 6m;
        const decimal squareFeetPerGallon = 330m;
        const decimal hourlyRate = 10.5m;


        public Program1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //declare variables
            decimal squareFeet = decimal.Parse(squareFeetTextBox.Text);
            int coatsDesired = int.Parse(coatsDesiredTextBox.Text);
            decimal paintPrice = decimal.Parse(paintPriceTextBox.Text);

            //calculate total square feet
            decimal totalSquareFeet = squareFeet * coatsDesired;

            //calculate the number of gallons required
            decimal gallonsRequired = totalSquareFeet / squareFeetPerGallon;

            //calculate gallons of paint purchased, with math ceiling
            decimal gallonsPurchased = Math.Ceiling(gallonsRequired);

            //calculate total hours required
            decimal hoursRequired = gallonsRequired * hoursRequiredPerGallon;

            //calculate total cost of paint
            decimal paintCost = gallonsPurchased * paintPrice;

            //calculate the labor cost
            decimal laborCost = hoursRequired * hourlyRate;

            //calcualte the total cost
            decimal totalCost = hoursRequired * hourlyRate + paintCost;

            //display total square feet to be painted output, formatted as one place past decimal
            totalSquareFeetOutputLabel.Text = totalSquareFeet.ToString("n1");

            //display gallons of paint required output, with gal abbreviation at the end
            gallonsOfPaintOutputLabel.Text = gallonsPurchased.ToString() + " gal";

            //display hours of labor required output, formatted as one place past decimal
            hourOfLaborOutputLabel.Text = hoursRequired.ToString("n1");

            //display cost of paint output, formatted as currency
            costOfPaintOutputLabel.Text = paintCost.ToString("c");

            //display the labor cost output, formatted as currency
            costOfLaborOutputLabel.Text = laborCost.ToString("c");

            //display the total cost output, formatted as currency
            totalCostOutputLabel.Text = totalCost.ToString("c");

        }

        private void gallonsOfPaintOutputLabel_Click(object sender, EventArgs e)
        {

        }

        private void totalSquareFeetOutputLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
