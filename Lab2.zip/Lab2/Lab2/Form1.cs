﻿//A2502, Lab 2, 2-5-17, CIS199-01, this lab requires user to enter data into the 4 text boxes and will output different variations of their name depending on which format they chooose.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Lab2 : Form
    {
        public Lab2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void format1Button_Click(object sender, EventArgs e)
        {
            //declare a string variable.
            string output;

            //concatenate the input and build the output string for format 1.
            output = preferredTitleTextBox.Text + " " + firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            //display the output in the output label control
            outputLabel.Text = output;
        }

        private void format2Button_Click(object sender, EventArgs e)
        {
            //declare a string variable.
            string output;

            //concatenate the input and build the output for format 2.
            output = firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            //display the output in the output label control
            outputLabel.Text = output;
        }

        private void format3Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //concatenate the input and build the ouput string for format 3
            output = firstNameTextBox.Text + " " + lastNameTextBox.Text;

            //display the output string in the output label control
            outputLabel.Text = output;
        }

        private void format4Buttton_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //concatenate the input and build the ouput string for format 4
            output = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text + ", " + preferredTitleTextBox.Text;

            //display the output string in the output label control
            outputLabel.Text = output;
        }

        private void format5Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //concatenate the input and build the output string for format 5
            output = lastNameTextBox.Text + ", " + firstNameTextBox.Text + " " + middleNameTextBox.Text;

            //display the output string in the output label control
            outputLabel.Text = output;
        }

        private void format6Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //concatenate the input and build the output string for format 6
            output = lastNameTextBox.Text + ", " + firstNameTextBox.Text;

            //display the output string in the output label control
            outputLabel.Text = output;
        }
    }
}
