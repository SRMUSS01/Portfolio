﻿namespace Lab2
{
    partial class Lab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.preferredTitleLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.preferredTitleTextBox = new System.Windows.Forms.TextBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format4Buttton = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(222, 22);
            this.firstNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(88, 20);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(204, 91);
            this.middleNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(103, 20);
            this.middleNameLabel.TabIndex = 1;
            this.middleNameLabel.Text = "Middle name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(220, 165);
            this.lastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(88, 20);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last name:";
            // 
            // preferredTitleLabel
            // 
            this.preferredTitleLabel.AutoSize = true;
            this.preferredTitleLabel.Location = new System.Drawing.Point(26, 242);
            this.preferredTitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.preferredTitleLabel.Name = "preferredTitleLabel";
            this.preferredTitleLabel.Size = new System.Drawing.Size(278, 20);
            this.preferredTitleLabel.TabIndex = 3;
            this.preferredTitleLabel.Text = "Preferred title (Mr., Mrs., Ms., Dr., etc.):";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(330, 17);
            this.firstNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(148, 26);
            this.firstNameTextBox.TabIndex = 4;
            this.firstNameTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(330, 91);
            this.middleNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(148, 26);
            this.middleNameTextBox.TabIndex = 5;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(330, 165);
            this.lastNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(148, 26);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // preferredTitleTextBox
            // 
            this.preferredTitleTextBox.Location = new System.Drawing.Point(330, 242);
            this.preferredTitleTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.preferredTitleTextBox.Name = "preferredTitleTextBox";
            this.preferredTitleTextBox.Size = new System.Drawing.Size(148, 26);
            this.preferredTitleTextBox.TabIndex = 7;
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(32, 297);
            this.outputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(449, 40);
            this.outputLabel.TabIndex = 8;
            // 
            // format1Button
            // 
            this.format1Button.Location = new System.Drawing.Point(22, 365);
            this.format1Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(112, 35);
            this.format1Button.TabIndex = 9;
            this.format1Button.Text = "Format 1";
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(144, 365);
            this.format2Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(112, 35);
            this.format2Button.TabIndex = 10;
            this.format2Button.Text = "Format 2";
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(266, 365);
            this.format3Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(112, 35);
            this.format3Button.TabIndex = 11;
            this.format3Button.Text = "Format 3";
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format4Buttton
            // 
            this.format4Buttton.Location = new System.Drawing.Point(387, 365);
            this.format4Buttton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format4Buttton.Name = "format4Buttton";
            this.format4Buttton.Size = new System.Drawing.Size(112, 35);
            this.format4Buttton.TabIndex = 12;
            this.format4Buttton.Text = "Format 4";
            this.format4Buttton.UseVisualStyleBackColor = true;
            this.format4Buttton.Click += new System.EventHandler(this.format4Buttton_Click);
            // 
            // format5Button
            // 
            this.format5Button.Location = new System.Drawing.Point(86, 409);
            this.format5Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(112, 35);
            this.format5Button.TabIndex = 13;
            this.format5Button.Text = "Format 5";
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // format6Button
            // 
            this.format6Button.Location = new System.Drawing.Point(330, 409);
            this.format6Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(112, 35);
            this.format6Button.TabIndex = 14;
            this.format6Button.Text = "Format 6";
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // Lab2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 460);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.format4Buttton);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.preferredTitleTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.preferredTitleLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Lab2";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label preferredTitleLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox preferredTitleTextBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format4Buttton;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Button format6Button;
    }
}

