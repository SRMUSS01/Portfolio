﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLabel = new System.Windows.Forms.Label();
            this.testScoreLabel = new System.Windows.Forms.Label();
            this.gpaTextBox = new System.Windows.Forms.TextBox();
            this.testScoreTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.acceptedLabel = new System.Windows.Forms.Label();
            this.rejectedLabel = new System.Windows.Forms.Label();
            this.acceptedOutputLabel = new System.Windows.Forms.Label();
            this.rejectedOuputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaLabel
            // 
            this.gpaLabel.AutoSize = true;
            this.gpaLabel.Location = new System.Drawing.Point(177, 52);
            this.gpaLabel.Name = "gpaLabel";
            this.gpaLabel.Size = new System.Drawing.Size(51, 20);
            this.gpaLabel.TabIndex = 0;
            this.gpaLabel.Text = "GPA: ";
            // 
            // testScoreLabel
            // 
            this.testScoreLabel.AutoSize = true;
            this.testScoreLabel.Location = new System.Drawing.Point(68, 104);
            this.testScoreLabel.Name = "testScoreLabel";
            this.testScoreLabel.Size = new System.Drawing.Size(160, 20);
            this.testScoreLabel.TabIndex = 1;
            this.testScoreLabel.Text = "Admission test score:";
            // 
            // gpaTextBox
            // 
            this.gpaTextBox.Location = new System.Drawing.Point(234, 49);
            this.gpaTextBox.Name = "gpaTextBox";
            this.gpaTextBox.Size = new System.Drawing.Size(100, 26);
            this.gpaTextBox.TabIndex = 2;
            // 
            // testScoreTextBox
            // 
            this.testScoreTextBox.Location = new System.Drawing.Point(234, 101);
            this.testScoreTextBox.Name = "testScoreTextBox";
            this.testScoreTextBox.Size = new System.Drawing.Size(100, 26);
            this.testScoreTextBox.TabIndex = 3;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(162, 176);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(79, 31);
            this.submitButton.TabIndex = 4;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // acceptedLabel
            // 
            this.acceptedLabel.AutoSize = true;
            this.acceptedLabel.Location = new System.Drawing.Point(158, 235);
            this.acceptedLabel.Name = "acceptedLabel";
            this.acceptedLabel.Size = new System.Drawing.Size(81, 20);
            this.acceptedLabel.TabIndex = 5;
            this.acceptedLabel.Text = "Accepted:";
            // 
            // rejectedLabel
            // 
            this.rejectedLabel.AutoSize = true;
            this.rejectedLabel.Location = new System.Drawing.Point(158, 281);
            this.rejectedLabel.Name = "rejectedLabel";
            this.rejectedLabel.Size = new System.Drawing.Size(77, 20);
            this.rejectedLabel.TabIndex = 6;
            this.rejectedLabel.Text = "Rejected:";
            // 
            // acceptedOutputLabel
            // 
            this.acceptedOutputLabel.AutoSize = true;
            this.acceptedOutputLabel.Location = new System.Drawing.Point(245, 235);
            this.acceptedOutputLabel.Name = "acceptedOutputLabel";
            this.acceptedOutputLabel.Size = new System.Drawing.Size(0, 20);
            this.acceptedOutputLabel.TabIndex = 7;
            // 
            // rejectedOuputLabel
            // 
            this.rejectedOuputLabel.AutoSize = true;
            this.rejectedOuputLabel.Location = new System.Drawing.Point(241, 281);
            this.rejectedOuputLabel.Name = "rejectedOuputLabel";
            this.rejectedOuputLabel.Size = new System.Drawing.Size(0, 20);
            this.rejectedOuputLabel.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 357);
            this.Controls.Add(this.rejectedOuputLabel);
            this.Controls.Add(this.acceptedOutputLabel);
            this.Controls.Add(this.rejectedLabel);
            this.Controls.Add(this.acceptedLabel);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.testScoreTextBox);
            this.Controls.Add(this.gpaTextBox);
            this.Controls.Add(this.testScoreLabel);
            this.Controls.Add(this.gpaLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLabel;
        private System.Windows.Forms.Label testScoreLabel;
        private System.Windows.Forms.TextBox gpaTextBox;
        private System.Windows.Forms.TextBox testScoreTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label acceptedLabel;
        private System.Windows.Forms.Label rejectedLabel;
        private System.Windows.Forms.Label acceptedOutputLabel;
        private System.Windows.Forms.Label rejectedOuputLabel;
    }
}

