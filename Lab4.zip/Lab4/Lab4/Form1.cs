﻿//A2502
//Lab 4
//2-19-17
//CIS150-01
//This lab allows users to enter their gpa and their admission test score
//based on the parameters given, a message will display letting them know if they are accepted or rejected
//it also keeps a running total of all entries accepted or rejected
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        //values for totals
        uint acceptedTotal = 0;
        uint rejectedTotal = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //declare variables
            double gpa;
            int testScore;

            //determine whether student is accepted or rejected
            if (double.TryParse(gpaTextBox.Text, out gpa) && (int.TryParse(testScoreTextBox.Text, out testScore)))

                if ((gpa >= 3.0 && testScore >= 60) || (gpa < 3.0 && testScore >= 80))
                {
                    MessageBox.Show("Accepted!"); //display accepted if meet requirements
                    acceptedTotal += 1; //adds to accepted total if they are accepted
                    acceptedOutputLabel.Text = acceptedTotal.ToString(); //displays accepted total
                }
                else
                {
                    MessageBox.Show("Rejected"); //display rejected if don't meet requirements
                    rejectedTotal += 1; //adds to rejected total if they are rejected
                    rejectedOuputLabel.Text = rejectedTotal.ToString(); //displays rejected total
                }
        }
    }
}
