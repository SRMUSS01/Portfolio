﻿//A2502
//CIS199-01
//3-9-17
//This program allows students to enter their last name into a text box and also select their grade. 
//It then assigns certain dates and times slots from the registration schedule based on their last name and grade. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        //declare variables
        char lastName;
        string date;
        string time;

        public Form1()
        {
            InitializeComponent();
        }

        private void regTimeButton_Click(object sender, EventArgs e)
        {

            if (seniorRadioButton.Checked) //checks if senior radio button is selected
            {
                date = "Wednesday, March 29th"; //date for seniors
            }
            else if (juniorRadioButton.Checked) //checks if junior radio button is selected
            {
                date = "Thursday, March 30th"; //date for juniors
            }
            lastName = lastNameTextBox.Text[0]; //sets the value for last name 

            if (juniorRadioButton.Checked || seniorRadioButton.Checked) // assigns time slots for juniors and seniors based on last name
            {
                //8:30 times slot for last name p-s
                if (lastName.Equals('p') || lastName.Equals('q') || lastName.Equals('r') || lastName.Equals('s'))
                {
                    time = "8:30am";
                }
                //10:00 time slot for last name t-z
                else if (lastName.Equals('t') || lastName.Equals('u') || lastName.Equals('v') || lastName.Equals('w') || lastName.Equals('x') || lastName.Equals('y') || lastName.Equals('z'))
                {
                    time = "10:00am";
                }
                //11:30 time slot for last name a-d
                else if (lastName.Equals('a') || lastName.Equals('b') || lastName.Equals('c') || lastName.Equals('d'))
                {
                    time = "11:30am";
                }
                //2:00 time slot for last name e-i
                else if (lastName.Equals('e') || lastName.Equals('f') || lastName.Equals('g') || lastName.Equals('h') || lastName.Equals('i'))
                {
                    time = "2:00pm";
                }
                //4:00 time slot for all other letters
                else
                {
                    time = "4:00pm";
                }

            }
            else //assigns time slots for freshmen and sophomores based on last name
            {
                //8:30 time slot for  last name p-q & c-d
                if (lastName.Equals('p') || lastName.Equals('q') || lastName.Equals('c') || lastName.Equals('d'))
                {
                    time = "8:30am";
                }
                //10:00 time slot for last name r-s & e-f
                else if (lastName.Equals('r') || lastName.Equals('s') || lastName.Equals('e') || lastName.Equals('f'))
                {
                    time = "10:00am";
                }
                //11:30 time slot for last name t-v & g-i
                else if (lastName.Equals('t') || lastName.Equals('u') || lastName.Equals('v') || lastName.Equals('g') || lastName.Equals('h') || lastName.Equals('i'))
                {
                    time = "11:30am";
                }
                //2:00 time slot for last name w-z & j-l
                else if (lastName.Equals('w') || lastName.Equals('x') || lastName.Equals('y') || lastName.Equals('z') || lastName.Equals('j') || lastName.Equals('k') || lastName.Equals('l'))
                {
                    time = "2:00pm";
                }
                //4:00 time slot for all other letters
                else 
                {
                    time = "4:00pm";
                }

                if (sophomoreRadioButton.Checked) //assigns date for sophomores based on last name
                {
                    //april 3rd for last names c-o, all else march 31st
                    if (lastName >= 'c' && lastName <= 'o')
                        date = "Monday, April 3rd";
                    else date = "Friday, March 31st";
                }
                if (freshmanRadioButton.Checked) //assigns date for freshmen based on last name 
                {
                    //april 5th for last names c-o, all else april 4th
                    if (lastName >= 'c' && lastName <= 'o')
                        date = "Wednesday, April 5th";
                    else date = "Tuesday, April 4th";
                }
            }

            regTimeOutputLabel.Text = date + " " + time; //outputs assigned date and time based on grade and last name

        }
    }
}
