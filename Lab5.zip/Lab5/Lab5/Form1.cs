﻿//A2502
//3-5-17
//CIS199-01
//This lab allows the user to enter a number, and select either a while loop, for loop, or do-while loop.  It then outputs the 
//pattern in the output listbox on the right.  If invalid data is entered, an error message appears.  There is also a clear
//button that will clear any data entered. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void runLoopButton_Click(object sender, EventArgs e)
        {
            //declare local variables
            int start;
            int end;
            int count;

            //get start value
            if (int.TryParse(fromTextBox.Text, out start))
            {
                //get end value
                if (int.TryParse(toTextBox.Text, out end))
                {
                    //count variable
                    count = start;

                    //while loop
                    if (whileRadioButton.Checked)
                    {
                        //calculate while loop count
                        while (count <= end)
                        {
                            //display the value in the output list box & add to counter
                            outputListBox.Items.Add(count);
                            count = count + 1;
                        }
                    }
                    //for loop
                    if (forRadioButton.Checked)
                    {
                        //calculate for loop
                        for (count = start; count <= end; count++)
                        {
                            //display the value in the ouptut list box
                            outputListBox.Items.Add(count);
                        }
                        //do-while loop
                        if (doWhilteRadioButton.Checked)
                        {
                            do
                            {
                                //display the value in the output list box & add to counter
                                outputListBox.Items.Add(count);
                                count = count + 1;
                            } while (count <= end);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You entered an invalid value");
                    }
                }
                else
                {
                    MessageBox.Show("You entered an invalid value");
                }
            }
        }
private void clearListButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Clear();
        }
    }
        }
