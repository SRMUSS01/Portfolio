﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fromLabel = new System.Windows.Forms.Label();
            this.toLabel = new System.Windows.Forms.Label();
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.toTextBox = new System.Windows.Forms.TextBox();
            this.loopUsingLabel = new System.Windows.Forms.Label();
            this.whileRadioButton = new System.Windows.Forms.RadioButton();
            this.forRadioButton = new System.Windows.Forms.RadioButton();
            this.doWhilteRadioButton = new System.Windows.Forms.RadioButton();
            this.outputListBox = new System.Windows.Forms.ListBox();
            this.runLoopButton = new System.Windows.Forms.Button();
            this.clearListButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(21, 18);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(50, 20);
            this.fromLabel.TabIndex = 0;
            this.fromLabel.Text = "From:";
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.Location = new System.Drawing.Point(21, 78);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(31, 20);
            this.toLabel.TabIndex = 1;
            this.toLabel.Text = "To:";
            // 
            // fromTextBox
            // 
            this.fromTextBox.Location = new System.Drawing.Point(25, 41);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(100, 26);
            this.fromTextBox.TabIndex = 2;
            // 
            // toTextBox
            // 
            this.toTextBox.Location = new System.Drawing.Point(25, 101);
            this.toTextBox.Name = "toTextBox";
            this.toTextBox.Size = new System.Drawing.Size(100, 26);
            this.toTextBox.TabIndex = 3;
            // 
            // loopUsingLabel
            // 
            this.loopUsingLabel.AutoSize = true;
            this.loopUsingLabel.Location = new System.Drawing.Point(43, 158);
            this.loopUsingLabel.Name = "loopUsingLabel";
            this.loopUsingLabel.Size = new System.Drawing.Size(94, 20);
            this.loopUsingLabel.TabIndex = 4;
            this.loopUsingLabel.Text = "Loop Using:";
            // 
            // whileRadioButton
            // 
            this.whileRadioButton.AutoSize = true;
            this.whileRadioButton.Location = new System.Drawing.Point(25, 190);
            this.whileRadioButton.Name = "whileRadioButton";
            this.whileRadioButton.Size = new System.Drawing.Size(69, 24);
            this.whileRadioButton.TabIndex = 5;
            this.whileRadioButton.TabStop = true;
            this.whileRadioButton.Text = "while";
            this.whileRadioButton.UseVisualStyleBackColor = true;
            // 
            // forRadioButton
            // 
            this.forRadioButton.AutoSize = true;
            this.forRadioButton.Location = new System.Drawing.Point(25, 220);
            this.forRadioButton.Name = "forRadioButton";
            this.forRadioButton.Size = new System.Drawing.Size(53, 24);
            this.forRadioButton.TabIndex = 6;
            this.forRadioButton.TabStop = true;
            this.forRadioButton.Text = "for";
            this.forRadioButton.UseVisualStyleBackColor = true;
            // 
            // doWhilteRadioButton
            // 
            this.doWhilteRadioButton.AutoSize = true;
            this.doWhilteRadioButton.Location = new System.Drawing.Point(25, 250);
            this.doWhilteRadioButton.Name = "doWhilteRadioButton";
            this.doWhilteRadioButton.Size = new System.Drawing.Size(92, 24);
            this.doWhilteRadioButton.TabIndex = 7;
            this.doWhilteRadioButton.TabStop = true;
            this.doWhilteRadioButton.Text = "do-while";
            this.doWhilteRadioButton.UseVisualStyleBackColor = true;
            // 
            // outputListBox
            // 
            this.outputListBox.FormattingEnabled = true;
            this.outputListBox.ItemHeight = 20;
            this.outputListBox.Location = new System.Drawing.Point(206, 27);
            this.outputListBox.Name = "outputListBox";
            this.outputListBox.Size = new System.Drawing.Size(208, 364);
            this.outputListBox.TabIndex = 8;
            // 
            // runLoopButton
            // 
            this.runLoopButton.Location = new System.Drawing.Point(25, 321);
            this.runLoopButton.Name = "runLoopButton";
            this.runLoopButton.Size = new System.Drawing.Size(100, 29);
            this.runLoopButton.TabIndex = 9;
            this.runLoopButton.Text = "Run Loop";
            this.runLoopButton.UseVisualStyleBackColor = true;
            this.runLoopButton.Click += new System.EventHandler(this.runLoopButton_Click);
            // 
            // clearListButton
            // 
            this.clearListButton.Location = new System.Drawing.Point(25, 369);
            this.clearListButton.Name = "clearListButton";
            this.clearListButton.Size = new System.Drawing.Size(100, 29);
            this.clearListButton.TabIndex = 10;
            this.clearListButton.Text = "Clear List";
            this.clearListButton.UseVisualStyleBackColor = true;
            this.clearListButton.Click += new System.EventHandler(this.clearListButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 410);
            this.Controls.Add(this.clearListButton);
            this.Controls.Add(this.runLoopButton);
            this.Controls.Add(this.outputListBox);
            this.Controls.Add(this.doWhilteRadioButton);
            this.Controls.Add(this.forRadioButton);
            this.Controls.Add(this.whileRadioButton);
            this.Controls.Add(this.loopUsingLabel);
            this.Controls.Add(this.toTextBox);
            this.Controls.Add(this.fromTextBox);
            this.Controls.Add(this.toLabel);
            this.Controls.Add(this.fromLabel);
            this.Name = "Form1";
            this.Text = "Lab 5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.TextBox toTextBox;
        private System.Windows.Forms.Label loopUsingLabel;
        private System.Windows.Forms.RadioButton whileRadioButton;
        private System.Windows.Forms.RadioButton forRadioButton;
        private System.Windows.Forms.RadioButton doWhilteRadioButton;
        private System.Windows.Forms.ListBox outputListBox;
        private System.Windows.Forms.Button runLoopButton;
        private System.Windows.Forms.Button clearListButton;
    }
}

