﻿namespace Lab1
{
    partial class Lab1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab1));
            this.dogPictureBox = new System.Windows.Forms.PictureBox();
            this.gradeIDLabel = new System.Windows.Forms.Label();
            this.hobbiesButton = new System.Windows.Forms.Button();
            this.bookButton = new System.Windows.Forms.Button();
            this.movieButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dogPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // dogPictureBox
            // 
            this.dogPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("dogPictureBox.Image")));
            this.dogPictureBox.Location = new System.Drawing.Point(114, 23);
            this.dogPictureBox.Name = "dogPictureBox";
            this.dogPictureBox.Size = new System.Drawing.Size(200, 250);
            this.dogPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dogPictureBox.TabIndex = 0;
            this.dogPictureBox.TabStop = false;
            this.dogPictureBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // gradeIDLabel
            // 
            this.gradeIDLabel.AutoSize = true;
            this.gradeIDLabel.Location = new System.Drawing.Point(186, 298);
            this.gradeIDLabel.Name = "gradeIDLabel";
            this.gradeIDLabel.Size = new System.Drawing.Size(56, 20);
            this.gradeIDLabel.TabIndex = 1;
            this.gradeIDLabel.Text = "A2502";
            this.gradeIDLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // hobbiesButton
            // 
            this.hobbiesButton.Location = new System.Drawing.Point(60, 339);
            this.hobbiesButton.Name = "hobbiesButton";
            this.hobbiesButton.Size = new System.Drawing.Size(91, 35);
            this.hobbiesButton.TabIndex = 2;
            this.hobbiesButton.Text = "Hobbies";
            this.hobbiesButton.UseVisualStyleBackColor = true;
            this.hobbiesButton.Click += new System.EventHandler(this.hobbiesButton_Click);
            // 
            // bookButton
            // 
            this.bookButton.Location = new System.Drawing.Point(180, 340);
            this.bookButton.Name = "bookButton";
            this.bookButton.Size = new System.Drawing.Size(80, 35);
            this.bookButton.TabIndex = 3;
            this.bookButton.Text = "Book";
            this.bookButton.UseVisualStyleBackColor = true;
            this.bookButton.Click += new System.EventHandler(this.bookButton_Click);
            // 
            // movieButton
            // 
            this.movieButton.Location = new System.Drawing.Point(289, 340);
            this.movieButton.Name = "movieButton";
            this.movieButton.Size = new System.Drawing.Size(80, 35);
            this.movieButton.TabIndex = 4;
            this.movieButton.Text = "Movie";
            this.movieButton.UseVisualStyleBackColor = true;
            this.movieButton.Click += new System.EventHandler(this.movieButton_Click);
            // 
            // Lab1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 429);
            this.Controls.Add(this.movieButton);
            this.Controls.Add(this.bookButton);
            this.Controls.Add(this.hobbiesButton);
            this.Controls.Add(this.gradeIDLabel);
            this.Controls.Add(this.dogPictureBox);
            this.Name = "Lab1";
            this.Text = "Lab1";
            this.Click += new System.EventHandler(this.hobbiesButton_Click);
            ((System.ComponentModel.ISupportInitialize)(this.dogPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox dogPictureBox;
        private System.Windows.Forms.Label gradeIDLabel;
        private System.Windows.Forms.Button hobbiesButton;
        private System.Windows.Forms.Button bookButton;
        private System.Windows.Forms.Button movieButton;
    }
}

