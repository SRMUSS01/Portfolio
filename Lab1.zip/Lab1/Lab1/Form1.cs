﻿/*A2502, Lab1, 1/29/17, CIS199-01
 * This program shows my favorite animal with my grading ID underneath.
 * When you click one of the buttons, my hobbies, favorite book, or favorite movie displays in a message box.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Lab1 : Form
    {
        public Lab1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void hobbiesButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("UofL sports, hanging with friends and family");

        }

        private void bookButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Harry Potter Series");
        }

        private void movieButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jurassic Park");

 }
    }
}
